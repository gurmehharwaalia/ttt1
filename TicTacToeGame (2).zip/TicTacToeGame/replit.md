# Tic-Tac-Toe Game

## Overview

This is a modern, interactive Tic-Tac-Toe game built with React, TypeScript, and Express. The application features a clean, minimalist design with a mint/teal color scheme, focusing on playful aesthetics and instant visual feedback. The game is fully responsive, providing an optimal experience on both mobile and desktop devices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast HMR (Hot Module Replacement)
- Wouter for lightweight client-side routing (alternative to React Router)

**UI Component Library:**
- Shadcn/ui components built on Radix UI primitives
- Tailwind CSS for utility-first styling with custom design tokens
- Component variants managed through class-variance-authority (CVA)
- Consistent design system using CSS custom properties for theming

**State Management:**
- React Query (@tanstack/react-query) for server state management
- Local component state using React hooks for game logic
- Custom hooks for reusable stateful logic (e.g., `useIsMobile`, `useToast`)

**Design Principles:**
- Playful minimalism with clean interface focusing on gameplay
- Clear visual hierarchy with the game board as the primary focal point
- Instant visual feedback through hover and active states
- Responsive design with mobile-first approach (breakpoint at 768px)

### Backend Architecture

**Server Framework:**
- Express.js as the HTTP server framework
- TypeScript for type safety across the entire stack
- ESM (ES Modules) for modern JavaScript module system

**Request/Response Handling:**
- JSON request body parsing with raw body capture for webhooks
- Custom logging middleware for API request tracking
- Response time monitoring built into middleware

**Development Setup:**
- Vite middleware integration for development mode
- Hot module replacement during development
- Static file serving in production mode
- Separate dev/production configurations

**Storage Layer:**
- In-memory storage implementation (`MemStorage`) for development/testing
- Interface-based storage design (`IStorage`) allowing easy swapping of implementations
- User CRUD operations with UUID-based identifiers
- Designed to be extended with database persistence (PostgreSQL ready via Drizzle configuration)

### Data Storage

**Database Configuration:**
- Drizzle ORM configured for PostgreSQL dialect
- Schema-first approach with TypeScript types inferred from schema
- Migration support via `drizzle-kit` (migrations output to `./migrations`)
- Neon Database serverless driver for PostgreSQL connections
- Zod integration for runtime validation through `drizzle-zod`

**Schema Design:**
- Users table with UUID primary keys (generated via `gen_random_uuid()`)
- Username uniqueness constraint
- Password storage (note: should be hashed in production)
- Type inference from Drizzle schema to TypeScript types

**Current Implementation:**
- In-memory storage for rapid prototyping without database dependency
- Database schema defined and ready for migration when needed
- Storage interface abstraction allows switching from memory to database without code changes

### External Dependencies

**UI Framework & Styling:**
- Radix UI component primitives for accessible, unstyled components
- Tailwind CSS v3 with custom configuration (neutral base color, CSS variables enabled)
- PostCSS with Autoprefixer for CSS processing
- Embla Carousel for potential carousel functionality
- Lucide React for iconography

**Development & Build Tools:**
- Vite with React plugin for fast development experience
- ESBuild for production server bundling
- TSX for running TypeScript in development
- Replit-specific plugins for error overlay, cartographer, and dev banner

**Form & Validation:**
- React Hook Form for form state management
- Zod for schema validation
- @hookform/resolvers for connecting Zod to React Hook Form

**Database & ORM:**
- Drizzle ORM for type-safe database queries
- @neondatabase/serverless for PostgreSQL connections
- drizzle-kit for schema migrations

**Utility Libraries:**
- clsx and tailwind-merge (via `cn` utility) for conditional className composition
- date-fns for date manipulation
- nanoid for generating unique identifiers
- cmdk for command menu functionality

**Session Management:**
- connect-pg-simple configured for PostgreSQL session storage (when database is enabled)

**Production Considerations:**
- Database URL must be set via `DATABASE_URL` environment variable
- Server runs on Node.js in production mode
- Build process bundles server code with ESBuild and client with Vite
- Static assets served from `dist/public` directory